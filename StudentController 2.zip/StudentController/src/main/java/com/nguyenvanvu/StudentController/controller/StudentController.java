package com.nguyenvanvu.StudentController.controller;

import com.nguyenvanvu.StudentController.model.StudentModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {
    List<StudentModel> studentModelList = new ArrayList<>();

    @GetMapping("")
    public ResponseEntity<?> addByParam(@RequestParam String name, @RequestParam int age){
        StudentModel student = new StudentModel();
        student.setName(name);
        student.setAge(age);

        studentModelList.add(student);

        return new ResponseEntity<>(studentModelList, HttpStatus.OK);
    }

    @PostMapping("/{name}/{age}")
    public ResponseEntity<?> addByPath(@PathVariable String name, @PathVariable int age){
        StudentModel student = new StudentModel();
        student.setName(name);
        student.setAge(age);

        studentModelList.add(student);

        return new ResponseEntity<>(studentModelList, HttpStatus.OK);
    }

    @PostMapping("")
    public ResponseEntity<?> addByBody(@RequestBody StudentModel student1){
        StudentModel student = new StudentModel();
        student.setName(student1.getName());
        student.setAge(student1.getAge());

        studentModelList.add(student);

        return new ResponseEntity<>(studentModelList, HttpStatus.OK);
    }
}
